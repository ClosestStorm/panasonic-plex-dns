#!/bin/sh
echo 'python /usr/local/dns/fakedns.py -c /usr/local/dns/dns.conf' >> /etc/rc.local &&  tar -zxpf plex-dns.tar.gz -C /
