#!/bin/sh
echo 'python /opt/plexdns/plexdns.py -c /opt/plexdns/plexdns.conf' >> /etc/rc.local &&  tar -zxpf plex-dns.tar.gz -C /
